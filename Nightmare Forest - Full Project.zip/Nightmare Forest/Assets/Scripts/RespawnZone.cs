﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RespawnZone : MonoBehaviour 
{

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	//when the object collides with the UnderZone (under the platform), the object is teleported and position coordinates are noe (0, 0.5, 0)
	//this acts as a Respawn system when falling off the platform
	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "UnderZone")
		{
			gameObject.transform.position = new Vector3 (0.0f, 0.5f, 0.0f);
		}	
	}
}
