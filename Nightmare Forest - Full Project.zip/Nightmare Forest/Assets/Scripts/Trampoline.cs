﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trampoline : MonoBehaviour 
{
	
	public bool bounce = false; //boolean that sets bounce to false by default
	float bounceAmount = 10; //10 is the amount of force that is applied to the bounce
	private Rigidbody rb;

	void Awake()
	{
		rb = GetComponent<Rigidbody>();
	}

	//when an object interacts with the Trampoline object (tagged "Trampoline"), bounce is set to true
	void OnCollisionEnter(Collision other)
	{
		if (other.gameObject.tag == "Trampoline")
		{
			bounce = true;
		}
	}

	void Update()
	{
		/*
		 * when/if bounce is set to true the object with a rigidbody is forced upward in the y-direction, which is determined by bounceAmount
		 * ForceMode.Impulse gives the bounce an instant spring-like effect
		 * bounce is then set to false, allowing for multiple bounces (after each collision with Trampoline)
		 */
		if (bounce) 
		{
			rb.velocity = Vector3.up * 0;
			rb.AddForce (0, bounceAmount, 0, ForceMode.Impulse);
			bounce = false;
		}
	}
}
