﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour 
{
	public KeyCode moveForward;
	public KeyCode moveLeft;
	public KeyCode moveRight;
	public KeyCode moveBackward;
	public KeyCode moveJump;
	private Rigidbody rb;
	public float speed;
	public bool enemyDrop = false;
	public bool mv3D = false;
	public bool lookBlocks = false;
    public Animation anim;
    public AudioClip jump;
    AudioSource audio;
    
		
	// Use this for important initializations
	void Awake()
	{
		//moveJump = KeyCode.Space;
		rb = GetComponent<Rigidbody>();
        anim = GetComponent<Animation>();
        audio = GetComponent<AudioSource>();
	}


	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
        Jump();
		Movement ();
		MV ();
        
		/*forwardMove();
		leftMove ();
		rightMove();
		backMove();*/
		//Jump(); //this is now located in an OnCollision event, check below
	}


	void Jump()
	{
		if (Input.GetKeyDown(moveJump)) 
		{
			rb.AddForce(Vector3.up * 350.0f);
			if (lookBlocks == false) 
			{

                audio.clip = jump;
                audio.Play();
            }
		}
	}
    
   


    void Movement()
	//void forwardMove ()
	{
		// This if-statement moves the player forward
		if (Input.GetKey (moveForward)) {
			gameObject.transform.position += gameObject.transform.forward * speed * Time.deltaTime;
            anim.Play("run");
           // StartCoroutine(RunSound());

            //rb.velocity = Vector3.forward * speed;
            /*if ((rb.velocity.magnitude < 10.0f) && (gameObject.transform.position.y > 0.5))
				{
					rb.velocity += Vector3.forward * speed;
				}
				else {
					rb.velocity = Vector3.forward * speed;
				}
			*/
            // Use this for simple objects that don't require a lot of detail
            //transform.Translate(Vector3.forward); // (0, 0, 1)
        } /*else {
			rb.velocity = Vector3.forward * 0;
		}
	}*/
        else if (Input.GetKeyUp(moveForward))
        {
            anim.Play("idle");
        }
        //void leftMove()
        //{
        if (Input.GetKey (moveLeft)) 
		{
            
            //gameObject.transform.position -= gameObject.transform.right * speed * Time.deltaTime;
            gameObject.transform.position += gameObject.transform.forward * speed * Time.deltaTime;
            anim.Play("run");
            //rb.velocity = Vector3.left * speed;
            /*if ((rb.velocity.magnitude < 10.0f) && (gameObject.transform.position.y > 0.5))
				{
					rb.velocity += Vector3.left * speed;
				}
				else{
					rb.velocity = Vector3.left * speed;
				}
			*/
            // Use this for simple objects that don't require a lot of detail
            //transform.Translate(Vector3.forward); // (-1, 0, 0)
        }
        else if (Input.GetKeyUp(moveLeft))
        {
            anim.Play("idle");
        }
        /*else {
			rb.velocity = Vector3.left * 0;
		}
	}*/


        //void rightMove()
        //{
        if (Input.GetKey(moveRight)) 
		{
            
            //gameObject.transform.position += gameObject.transform.right * speed * Time.deltaTime;
            gameObject.transform.position += gameObject.transform.forward * speed * Time.deltaTime;
            anim.Play("run");
            //rb.velocity = Vector3.right * speed;
            /*if ((rb.velocity.magnitude < 10.0f) && (gameObject.transform.position.y > 0.5))
				{
					rb.velocity += Vector3.right * speed;
				}
				else{
					rb.velocity = Vector3.right * speed;
				}
			*/
            // Use this for simple objects that don't require a lot of detail
            //transform.Translate(Vector3.forward); // (1, 0, 0)
        }
        else if (Input.GetKeyUp(moveRight))
        {
            anim.Play("idle");
        }
        /*else {
			rb.velocity = Vector3.right * 0;
		}
	}*/

        //void backMove()
        //{
        if (Input.GetKey (moveBackward)) 
		{
			//gameObject.transform.position -= gameObject.transform.forward * speed * Time.deltaTime;
			gameObject.transform.position += gameObject.transform.forward * speed * Time.deltaTime;
            anim.Play("run");
            //rb.velocity = Vector3.back * speed;
            /*if ((rb.velocity.magnitude < 10.0f) && (gameObject.transform.position.y > 0.5))
				{
					rb.velocity += Vector3.back * speed;
				}
				else{
					rb.velocity = Vector3.back * speed;
				}
			*/
            // Use this for simple objects that don't require a lot of detail
            //transform.Translate(Vector3.forward); // (0, 0, -1)
        }
        else if (Input.GetKeyUp(moveBackward))
        {
            anim.Play("idle");
        }
        /*else {
			rb.velocity = Vector3.back * 0;
		}*/

    }

	/*
	 * Jump() is now part of this OnCollisionStay
	 * The Player must be colliding with an object to be able to jump
	 * This enables the Player to only have a single jump
	 */
	void OnCollisionStay(Collision collision)
	{
		//Jump();
	}

	/*IEnumerator OnTriggerEnter(Collider other)
	{
		//when object collides with the cylinder PickUp, 20 is added to the health; the new health is then printed onto the console
		if (other.gameObject.tag == "PickUp")
		{
			speed = speed / 2;
			yield return new WaitForSeconds(5);
			speed = speed * 2;
		}
	}*/

	void OnTriggerEnter (Collider nope)
	{
		if (nope.gameObject.tag == "3DMove") 
		{
			moveLeft = KeyCode.W;
			moveRight = KeyCode.S;
			mv3D = true;
		}

		if (nope.gameObject == GameObject.FindGameObjectWithTag("EnemyDropTrigger"))
		{
			enemyDrop = true;
		}

	}

	void OnTriggerExit (Collider cube)
	{
		if (cube.gameObject.tag == "3DMove") 
		{
			moveLeft = KeyCode.None;
			moveRight = KeyCode.None;
			mv3D = false;
		}
	}

	public void MV()
	{
		if (lookBlocks == true)
		{
			if (GameObject.Find ("Player").GetComponent<PlayerMovement> ().mv3D == true) {
				moveForward = KeyCode.W;
				moveBackward = KeyCode.S;
			} else {
				moveForward = KeyCode.None;
				moveBackward = KeyCode.None;
			}
		}
	}


    /*
	void OnCollisionEnter(Collision collision)
    {
        
    }
		
    void OnCollisionExit(Collision collision)
    {
        
    }
    */
}