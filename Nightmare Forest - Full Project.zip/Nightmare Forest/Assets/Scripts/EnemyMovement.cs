﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour 
{

	public GameObject[] waypoints;
	public int num = 0;
	public float minDist;
	public float speed;
	public bool rand = false;
	public bool go = true;
	public bool chase = false;
	public Transform target;
	public float sightDist;
	public float attackDist;
    AudioSource audio;
    public AudioClip move;

    private void Start()
    {
        audio = GetComponent<AudioSource>();
    }
    void Update () 
	{
		MoveTo ();
		Sight ();
		Attack ();
		Chase ();
		noChase ();
	}

	public void Sight()
	{
		RaycastHit hit;
		Ray sightRay = new Ray (transform.position + Vector3.up * 2, transform.forward );

		Debug.DrawRay (transform.position + Vector3.up * 2, transform.forward * sightDist, Color.red);

		if (Physics.Raycast (sightRay, out hit, sightDist)) //ray is in center of AI
		{
			if (hit.collider.tag == "Player") 
			{
				go = false;
				chase = true;
				print ("Enemy: I'm coming to get you!");
			}
		}
	}

	public void Chase()
	{
		if (chase == true) 
		{
           // audio.clip = move;
           // audio.Play();
            transform.LookAt (target);
			transform.Translate (Vector3.forward * speed * Time.deltaTime);
		}
	}

	public void noChase()
	{
		if (GameObject.Find("z@walk").GetComponent<EnemyHealth>().runAway == true || GameObject.Find("elf demo").GetComponent<HideToBush>().noMoChase == true)
		{
			chase = false;
		}
	}

	public void Attack()
	{
		RaycastHit hit;
		Ray sightRay = new Ray (transform.position, transform.forward);

		Debug.DrawRay (transform.position, transform.forward * attackDist);

		if (Physics.Raycast (sightRay, out hit, sightDist)) //ray is in center of AI
		{
			if (hit.collider.tag == "Player") 
			{
				/*Add code here to deal damage to player*/
				print ("Enemy: I got you!");
			}
		}
	}
		

	public void MoveTo()
	{
		float dist = Vector3.Distance (gameObject.transform.position, waypoints [num].transform.position);

		if (go) //if go is true
		{
			if (dist > minDist) //if AI is not at next waypoint, then moves to waypoint
			{
               
				Move ();
			} 
			else 
			{

				if (num == 0) 
				{
					num++;
				}
				else if (num + 1 == waypoints.Length) 
				{
					num = 0;
				} 
				else 
				{
					num++;
				}

				/*if (!rand) //if rand is not selected, then follows set order of waypoints
				{
					if (num + 1 == waypoints.Length) 
					{
						num = 0;
					} 
					else 
					{
						num++;
					}
				} 
				else //if randon is selected
				{
					num = Random.Range (0, waypoints.Length); //if rand true, then select random waypoint
				}*/
			}
		}
	}

	public void Move()
	{
      //  audio.clip = move;
      //  audio.Play();
        gameObject.transform.LookAt(waypoints[num].transform.position);	//gameObject looks at specified waypoint
		gameObject.transform.position += gameObject.transform.forward * speed * Time.deltaTime; //moves AI forward to waypoint
	}

}
