﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundMusic : MonoBehaviour {
    public AudioClip FF;
    AudioSource ff;
    GameObject canvas;

    // Use this for initialization
    void Start () {
        ff = GetComponent<AudioSource>();
        canvas = GameObject.FindGameObjectWithTag("EndCanvas");
    }
	
	// Update is called once per frame
	void Update () {
		if (canvas.GetComponent<Canvas>().enabled == true)
        {
            ff.clip = FF;
            ff.Play();
        }
	}
}
