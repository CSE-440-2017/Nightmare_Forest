﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSkill : MonoBehaviour {
    public Animation anim;
    public KeyCode useSkill;
    public float playAnim = 0.1f;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        skill();
    }

    void skill()
    {
        if (Input.GetKeyDown(useSkill))
        {
            anim.Play("skill");
        }
        if (Input.GetKeyUp(useSkill))
        {
            StartCoroutine(WaitAnim());
        }
    }

   IEnumerator WaitAnim()
    {
        yield return new WaitForSeconds(playAnim);
        anim.Play("idle");
    }
}
