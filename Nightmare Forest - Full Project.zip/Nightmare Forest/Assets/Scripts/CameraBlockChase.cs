﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraBlockChase : MonoBehaviour {
    public Transform player;
    UnityEngine.AI.NavMeshAgent nav;
    public float speed;
    
    // Use this for initialization
    void Start () {
        
        nav = GetComponent<UnityEngine.AI.NavMeshAgent>();
    }
	
	// Update is called once per frame
	void Update () {
        Chase();
	}

    public void Chase()
    {
        nav.SetDestination(GameObject.FindGameObjectWithTag("Player").transform.position );

        transform.LookAt(GameObject.FindGameObjectWithTag("Player").transform );
        
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
        
    }
}
