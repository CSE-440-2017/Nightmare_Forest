﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttack : MonoBehaviour {

    public bool attack;
    
	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
        

    }

    void isAttacking()
    {
        GameObject.FindWithTag("EAHitbox").GetComponent<CapsuleCollider>().enabled = true; //this allows use of capsule collider flashlight (eliminates need for raycast; now only prefernece)
        
        attack = true;

        StartCoroutine(notAttacking());

    }
  IEnumerator notAttacking()
    {
        
        yield return new WaitForSeconds(1.0f);
        GameObject.FindWithTag("EAHitbox").GetComponent<CapsuleCollider>().enabled = false; //this allows use of capsule collider flashlight (eliminates need for raycast; now only prefernece)
      
        attack = false;
    }
}

