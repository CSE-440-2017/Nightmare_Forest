﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour {

	public GameObject[] waypoints;
	public int num = 0;
	public float minDist;
	public float speed;
	public bool runAway = false;
	public bool rand = false;
    AudioSource audio;
    public AudioClip hurt;
    // Update is called once per frame

    private void Start()
    {
        audio = GetComponent<AudioSource>();
    }
    void Update () 
	{
		RunAway ();
		GotFlashed ();
	}

    IEnumerator DestroyEnemy()
    {
        yield return new WaitForSeconds(2.0f);
        Destroy(gameObject);
    }
    void OnTriggerEnter (Collider other)
	{
		//if (other.gameObject.tag == "FlashTest" && GameObject.Find ("Player").GetComponent<Flashlight> ().flashOn == true)

		//use this, if you using capsule collider method for flashlight
		if (other.gameObject.tag == "FlashTest" && GameObject.Find ("elf demo").GetComponent<Flashlight> ().flashOn == true)
		{
			runAway = true;
            audio.clip = hurt;
            audio.Play();
		}if (other.gameObject.tag == "ZombDieZone") 
		{
            
            StartCoroutine(DestroyEnemy());
		}

		
	 }

	public void GotFlashed()
	{
		//use this, if using raycast method for flashlight
		/*if (GameObject.Find ("Cylinder010").GetComponent<FlashRaycast> ().flashed == true && GameObject.Find ("elf demo").GetComponent<Flashlight> ().flashOn == true)
		{
			runAway = true;
		}*/
	}
		

	public void RunAway()
	{
		float dist = Vector3.Distance (gameObject.transform.position, waypoints [num].transform.position);
		if (runAway == true) 
		{
			if (dist > minDist) //if AI is not at next waypoint, then moves to waypoint
			{
				Move ();
			} 
			else 
			{
				if (num == 0) 
				{
					num++;
				}

				if (!rand) //if rand is not selected, then follows set order of waypoints
				{
					if (num + 1 == waypoints.Length) 
					{
						num = 0;
					} 
					else 
					{
						num++;
					}
				} 
				else //if randon is selected
				{
					num = Random.Range (0, waypoints.Length); //if rand true, then select random waypoint
				}
			}
		}
	}

	public void Move()
	{
		gameObject.transform.LookAt(waypoints[num].transform.position);	//gameObject looks at specified waypoint
		gameObject.transform.position += gameObject.transform.forward * speed * Time.deltaTime; //moves AI forward to waypoint
	}
}
