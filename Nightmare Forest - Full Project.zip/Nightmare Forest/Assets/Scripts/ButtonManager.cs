﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ButtonManager : MonoBehaviour {
    public GameObject menu;
    public KeyCode openMenu;
   public bool isPaused;
    private void Start()
    {
        
        menu = GameObject.FindGameObjectWithTag("Menu");
       
    }
    private void Update()
    {
        GamePaused();
        OpenMenu();
    }
    public void StartGameButton(string newGame)
    {
        SceneManager.LoadScene(newGame);
    }
    public void Quit(string exitGame)
    {

        Debug.Log("exiting");
        Application.Quit();

    }
   /* public void Resume(string resume)
    {

            menu.GetComponent<Canvas>().enabled = false;
            isPaused = false;
       
       
    }*/

    void OpenMenu()
    {
        if (Input.GetKeyDown(openMenu))
        {
            if (menu.GetComponent<Canvas>().enabled == true)
            {
                menu.GetComponent<Canvas>().enabled = false;
                isPaused = false;
            }
            else
            {
                menu.GetComponent<Canvas>().enabled = true;
                isPaused = true;
            }
        }
    }
    
    void GamePaused()
    {
        if (isPaused == true)
        {
            Time.timeScale = 0;
        }
        else
        {
            Time.timeScale = 1;
        }
    }
}
