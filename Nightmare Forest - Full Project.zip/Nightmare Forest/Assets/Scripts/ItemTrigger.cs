﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemTrigger : MonoBehaviour {

    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        ItemComplete();
    }

    private void ItemComplete()
    {
        if (GameObject.FindGameObjectWithTag("Item1").GetComponent<MeshRenderer>().enabled == true && GameObject.FindGameObjectWithTag("Item2").GetComponent<MeshRenderer>().enabled == true && GameObject.FindGameObjectWithTag("Item3").GetComponent<MeshRenderer>().enabled == true)
        {
            gameObject.SetActive(false);
        }
    }
}
