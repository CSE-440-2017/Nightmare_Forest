﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveLook : MonoBehaviour {

	public KeyCode moveForward;
	public KeyCode moveLeft;
	public KeyCode moveRight;
	public KeyCode moveBackward;
	public KeyCode moveJump;
	public Transform mvFwd;
	public Transform mvLt;
	public Transform mvRt;
	public Transform mvBk;

	void Update()
	{
		Look ();
		//Look3D ();
	}

	void Look()
	{
		if (Input.GetKey (moveForward)) 
		{
			transform.LookAt(mvFwd);
			//transform.LookAt(Vector3.forward);
		}
		
		if (Input.GetKey (moveLeft)) 
		{
			transform.LookAt(mvLt);
			//transform.LookAt(Vector3.left);
		}

		if (Input.GetKey(moveRight)) 
		{
			transform.LookAt(mvRt);
			//transform.LookAt(Vector3.right);
		}

		if (Input.GetKey (moveBackward)) 
		{
			transform.LookAt(mvBk);
			//transform.LookAt(Vector3.back);
		}
	}

	/*void Look3D()
	{
		if (GameObject.Find ("Player").GetComponent<PlayerMovement> ().mv3D == true) 
		{
			if (Input.GetKey (moveForward))
			{
				transform.LookAt(mvFwd);
				//transform.LookAt(Vector3.forward);
			}

			if (Input.GetKey (moveBackward)) 
			{
				transform.LookAt(mvBk);
				//transform.LookAt(Vector3.back);
			}
		} 
	}*/

	/*public void Move3D()
	{
		if (GameObject.Find ("Player").GetComponent<PlayerMovement> ().mv3D == true) 
		{

		}
	}*/
}
