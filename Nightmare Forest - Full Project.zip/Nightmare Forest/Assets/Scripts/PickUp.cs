﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUp : MonoBehaviour 
{

	List<GameObject> PickUps = new List<GameObject>();

	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}

	void LateUpdate()
	{
		//This List will gather all of the GameObjects that are tagged in a list

		PickUps.AddRange(GameObject.FindGameObjectsWithTag("PickUp"));

		gameObject.transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);
	}
		
	//When the object with tag Player collides with the cylinder, the event is triggered and the cylinder is then destroyed
	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Player") 
		{
			Destroy(gameObject);
		}
	}

	/* In order for OnTrigger functions to work, they need a Collider Component and a Collider parameter
    void OnTriggerStay(Collider other)
    {
        
    }

    void OnTriggerExit(Collider other)
    {
        
    }
    */
}
