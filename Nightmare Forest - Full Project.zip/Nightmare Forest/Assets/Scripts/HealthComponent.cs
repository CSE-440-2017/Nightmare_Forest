﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class HealthComponent : MonoBehaviour
{
    public AudioClip hurt;
    AudioSource audio;
   
       
    
    public Slider slider;
    public float  Health;
    [SerializeField]
    private Image content;
	private Rigidbody rb;
    
	// Use this for initialization
	void Start () {
        audio = GetComponent<AudioSource>();
    }

	

	void OnTriggerEnter(Collider other)
	{
		//when object collides with the cylinder PickUp, 20 is added to the health; the new health is then printed onto the console
		if (other.gameObject.tag == "PickUp")
		{
            if (Health < 3)
                Health = Health + 1;
			print (Health);
		}
        if (GameObject.FindGameObjectWithTag("Enemy").GetComponent<EnemyAttack>().attack == true && other.gameObject.tag == "EAHitbox")
        {
            audio.clip = hurt;
            audio.Play();
            Health = Health - 1;
        }
	}
		
	// Update is called once per frame
	void Update () 
	{
		//if health is 0, then the object is deactivated
		if (Health <= 0 ) 
		{
			gameObject.SetActive(false);
		}
        slider.value = Health;
	}

  
}
