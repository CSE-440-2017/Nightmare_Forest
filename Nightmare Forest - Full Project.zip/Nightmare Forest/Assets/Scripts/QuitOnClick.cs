﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuitOnClick : MonoBehaviour {

    // Use this for initialization
    public void Quit(string exitGame)
    {

        Debug.Log("exiting");
		Application.Quit();
        
    }
}
