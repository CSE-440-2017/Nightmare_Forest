using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemPlaced : MonoBehaviour {

	//this script is currently not in use

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		//ShowUp ();
	}

	/*void OnTriggerStay (Collider placed)
	{
		if (placed.gameObject.tag == "DropZone") 
		{
			if (GameObject.Find("Player").GetComponent<InvenItems> ().itemPlaced == true) 
			{
				gameObject.GetComponent<MeshRenderer> ().enabled = true;
			}
		}
	}*/

	/*void ShowUp()
	{
		if (GameObject.Find ("Player").GetComponent<InvenItems> ().itemPlaced == true) 
		{
			gameObject.GetComponent<MeshRenderer> ().enabled = true;
		}
	}*/
}
