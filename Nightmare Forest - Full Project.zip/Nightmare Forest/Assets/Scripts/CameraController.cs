﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour 
{
	private GameObject Camera;
	private Vector3 offset;

	void Awake()
	{
		Camera = GameObject.FindWithTag ("cameralook");
		offset = gameObject.transform.position - Camera.transform.position;
	}

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		gameObject.transform.position = Camera.transform.position + offset;	
	}
}
