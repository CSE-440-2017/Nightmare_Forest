﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SightAI : MonoBehaviour {

	public float sightDist;
	public bool detected = false;

	
	// Update is called once per frame
	void Update () 
	{
		RaycastHit hit;
		Ray sightRay = new Ray (transform.position, transform.forward);

		Debug.DrawRay (transform.position, transform.forward * sightDist);
		Debug.DrawRay (transform.position, (transform.forward + transform.right).normalized * sightDist);
		Debug.DrawRay (transform.position, (transform.forward - transform.right).normalized * sightDist);

		if (Physics.Raycast (sightRay, out hit, sightDist)) //ray is in center of AI
		{
			if (hit.collider.tag == "Player") 
			{
				detected = true; //player is seen by AI
				print ("I see you");
			}
		}
		if (Physics.Raycast (transform.position, (transform.forward + transform.right).normalized, out hit, sightDist)) //ray is approx 45 degress to the right
		{
			if (hit.collider.tag == "Player") 
			{
				detected = true; //player is seen by AI
				print ("I see you");
			}
		}
		if (Physics.Raycast (transform.position, (transform.forward - transform.right).normalized, out hit, sightDist)) //ray is approx 45 degress to the left
		{
			if (hit.collider.tag == "Player") 
			{
				detected = true; //player is seen by AI
				print ("I see you");
			}
		}


	}
}
