﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlashRaycast : MonoBehaviour {

	/* 
	 *Use this script if using raycast method for flashlight 
	 */

	public float sightDist;
	public bool flashed = false;

	// Update is called once per frame
	void Update () 
	{
		LightHit ();
	}

	public void LightHit()
	{
		RaycastHit hit;
		Ray sightRay = new Ray (transform.position, transform.forward);

		Debug.DrawRay (transform.position, transform.forward * sightDist);

		if (Physics.Raycast (sightRay, out hit, sightDist)) //ray is in center of flash
		{
			if (hit.collider.tag == "Enemy" && GameObject.Find ("elf demo").GetComponent<Flashlight> ().flashOn == true) 
			{
				flashed = true; //enemy is hit by flashlight light
			}
		}
		else
		{
			flashed = false;	
		}
	}
}
