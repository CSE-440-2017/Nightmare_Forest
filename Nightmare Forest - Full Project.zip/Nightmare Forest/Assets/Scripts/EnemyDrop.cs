﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyDrop : MonoBehaviour 
{

	public bool enemyDrop = false;

	void Update()
	{
		Drop();
	}

	public void Drop()
	{
		//if (GameObject.Find ("Player").GetComponent<PlayerMovement> ().enemyDrop == true)
		if (GameObject.Find ("elf demo").GetComponent<PlayerMovement> ().enemyDrop == true)
		{
			gameObject.SetActive (false);
		}
	}

}