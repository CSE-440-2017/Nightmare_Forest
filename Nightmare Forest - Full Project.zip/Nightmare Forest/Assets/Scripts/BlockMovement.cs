﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockMovement : MonoBehaviour 
{
	public KeyCode moveForward;
	public KeyCode moveLeft;
	public KeyCode moveRight;
	public KeyCode moveBackward;
	public float speed;
    public KeyCode jump;
  
	// Update is called once per frame
	void Update () 
	{
		MvBlock ();
		MvMore ();
	}

	void MvBlock()
	{
		if (Input.GetKey (moveForward)) 
		{
			gameObject.transform.position += gameObject.transform.forward * speed * Time.deltaTime;
		}

		if (Input.GetKey (moveLeft))
		{
			gameObject.transform.position -= gameObject.transform.right * speed * Time.deltaTime;
		}

		if (Input.GetKey (moveRight)) 
		{
			gameObject.transform.position += gameObject.transform.right * speed * Time.deltaTime;
		}

		if (Input.GetKey (moveBackward))
		{
			gameObject.transform.position -= gameObject.transform.forward * speed * Time.deltaTime;
		}

      
	}

	void MvMore()
	{
		//if (GameObject.Find ("Player").GetComponent<PlayerMovement> ().mv3D == true)
		if (GameObject.Find ("elf demo").GetComponent<PlayerMovement> ().mv3D == true) 
		{
			moveForward = KeyCode.W;
			moveBackward = KeyCode.S;
		} 
		else {
			moveForward = KeyCode.None;
			moveBackward = KeyCode.None;
		}
	}
}
