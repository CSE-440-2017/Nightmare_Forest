﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flashlight : MonoBehaviour {

	public KeyCode flash;
	public bool flashOn;
	
	// Update is called once per frame
	void Update () 
	{
		FlashOn ();
	}

	//so far, just early testing
	public void FlashOn()
	{
		if (Input.GetKey (flash)) 
		{
			GameObject.Find ("FlashTest").GetComponent<CapsuleCollider> ().enabled = true; //this allows use of capsule collider flashlight (eliminates need for raycast; now only prefernece)
			GameObject.Find ("FlashTest").GetComponent<MeshRenderer> ().enabled = true;
			flashOn = true;
		} 
		else 
		{
			GameObject.Find ("FlashTest").GetComponent<CapsuleCollider> ().enabled = false;
			GameObject.Find ("FlashTest").GetComponent<MeshRenderer> ().enabled = false;
			flashOn = false;
		}
	}

}
