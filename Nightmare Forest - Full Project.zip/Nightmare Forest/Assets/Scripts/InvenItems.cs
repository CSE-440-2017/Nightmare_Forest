using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InvenItems : MonoBehaviour {

	public int currNumItems = 0;
	public KeyCode dropOff;
	public bool dropAvail;
	//public bool itemPlaced = false;

	// Update is called once per frame
	void Update () 
	{
		DropOffItem ();
	}

	void OnTriggerEnter (Collider other)
	{
		if (other.gameObject.tag == "PickUp") 
		{
			currNumItems++;
		}

	}

	void OnTriggerStay (Collider drop)
	{
		if (drop.gameObject.tag == "DropZone") 
		{
			if (Input.GetKeyDown (dropOff) && dropAvail == true) 
			{
				currNumItems--;
				//itemPlaced = true;
				GameObject.Find("Item1").GetComponent<MeshRenderer> ().enabled = true;
				GameObject.Find ("DropZone").SetActive (false);
			}
		}

		if (drop.gameObject.tag == "DropZone2") 
		{
			if (Input.GetKeyDown (dropOff) && dropAvail == true) 
			{
				currNumItems--;
				//itemPlaced = true;
				GameObject.Find("Item2").GetComponent<MeshRenderer> ().enabled = true;
				GameObject.Find ("DropZone2").SetActive (false);
			}
		}

		if (drop.gameObject.tag == "DropZone3") 
		{
			if (Input.GetKeyDown (dropOff) && dropAvail == true) 
			{
				currNumItems--;
				//itemPlaced = true;
				GameObject.Find("Item3").GetComponent<MeshRenderer> ().enabled = true;
				GameObject.Find ("DropZone3").SetActive (false);
			}
		}
	}

		
	public void DropOffItem()
	{
		if (currNumItems > 0) {
			dropAvail = true;
		} 
		else 
		{
			dropAvail = false;
		}
			
	}
}
