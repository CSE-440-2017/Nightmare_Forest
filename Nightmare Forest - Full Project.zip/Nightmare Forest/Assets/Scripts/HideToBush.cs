﻿	using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HideToBush : MonoBehaviour 
{

	public GameObject[] waypoints;
	public GameObject[] pointways;
	//public GameObject[] OnPath;
	public int num = 0;
	public float minDist;
	public float speed = 3;
	public KeyCode goHide;
	public KeyCode outHide;
	public bool hidden = false;
	public bool hidePossible = false;
	public bool noMoChase = false;
	public Animation anim;

	void Start()
	{
		anim = GetComponent<Animation> ();
	}

	// Update is called once per frame
	void Update () 
	{
		Hide ();
		noHide ();
	}

	public void Hide()
	{
		float dist = Vector3.Distance (gameObject.transform.position, waypoints [num].transform.position);
		if (hidePossible == true && hidden == false && Input.GetKey (goHide)) {
			noMoChase = true;
			if (dist > minDist) { //if AI is not at next waypoint, then moves to waypoint
				Move ();
			} else {
				if (num == 0) {
					num++;
				}

			}
		} 
		else 
		{
			noMoChase = false;
		}
	}

	public void noHide()
	{
		float dist = Vector3.Distance (gameObject.transform.position, pointways [num].transform.position);
		if (hidden == true && Input.GetKey (outHide))
		{
			if (dist > minDist) //if AI is not at next waypoint, then moves to waypoint
			{
				Move ();
			} 
			else 
			{
				if (num == 0) 
				{
					num++;
				}

			}
		}
	}

	void OnTriggerStay (Collider other)
	{
		if (other.gameObject.tag == "goHideArea") 
		{
			hidePossible = true;
			/*if (!Input.GetKey (goHide))
			{
				gameObject.transform.LookAt(OnPath[num].transform.position);
				gameObject.transform.position += gameObject.transform.forward * speed * Time.deltaTime;
			}*/
		}
			
	}
		

	IEnumerator OnTriggerEnter (Collider other)
	{
		if (other.gameObject.tag == "HiddenArea") 
		{

			num = 0;
			hidden = true;
			hidePossible = false;
			speed = 0;
			yield return new WaitForSeconds (1);
			speed = 5;
		}

	}

	public void Move()
	{
		if (hidePossible == true && hidden == false) 
		{
			gameObject.transform.LookAt (waypoints [num].transform.position);
			anim.Play ("run");
		}
		else 
		{
			if (hidden == true)
				gameObject.transform.LookAt(pointways[num].transform.position);
			anim.Play ("run");
		}
		gameObject.transform.position += gameObject.transform.forward * speed * Time.deltaTime;
	}
}
